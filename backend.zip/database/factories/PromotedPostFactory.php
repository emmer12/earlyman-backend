<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Models\PromotedPost;
use Faker\Generator as Faker;

$factory->define(PromotedPost::class, function (Faker $faker) {
    return [
        //
    ];
});
